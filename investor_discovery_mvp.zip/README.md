# Investor Discovery MVP

This is a minimum viable product (MVP) for a platform that helps match investment bankers and capital seekers with relevant investors.

## Features
- Extracts fund names, cheque sizes, sectors, and geographies from mock news articles
- Stores the data in a SQLite database
- Streamlit UI for filtering and exploring the data

## How to Run

1. Install requirements:
```
pip install -r requirements.txt
```

2. Run the Streamlit app:
```
streamlit run investor_match_mvp.py
```
